@extends('layouts.app')

@section('content')<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to the Enrollment System</title>
    <link rel="stylesheet" href="{{ mix('css/app.css') }}">
    <script src="{{ mix('js/app.js') }}" defer></script>
</head>
<body>
<div class="container">
    <h1>Welcome to the UPM Enrollment System</h1>
    <p>This is a simple enrollment system for students and professors.</p>
    <a href="{{ route('login') }}">Login</a> |
    <a href="{{ route('register') }}">Register</a>
</div>
</body>
</html>

@endsection
