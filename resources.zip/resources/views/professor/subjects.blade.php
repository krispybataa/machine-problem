@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Add Subject</h1>
        <form action="{{ route('professor.subjects.add') }}" method="POST">
            @csrf
            <input type="text" name="name" placeholder="Subject Name" required>
            <input type="number" name="available_slots" placeholder="Available Slots" required>
            <button type="submit">Add Subject</button>
        </form>
    </div>
@endsection
