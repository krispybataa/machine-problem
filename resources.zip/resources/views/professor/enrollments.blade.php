@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Enrolled Students</h1>
        <ul>
            @foreach($enrollments as $enrollment)
                <li>
                    {{ $enrollment->user->name }}
                    <form action="{{ route('professor.subjects.remove', ['subject_id' => $subject->id, 'student_id' => $enrollment->user->id]) }}" method="POST">
                        @csrf
                        <button type="submit">Remove</button>
                    </form>
                </li>
            @endforeach
        </ul>
    </div>
@endsection
