@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Search Subjects</h1>
        <form action="{{ route('student.subjects') }}" method="GET">
            <input type="text" name="search" placeholder="Search for subjects">
            <button type="submit">Search</button>
        </form>
        @if(isset($subjects))
            <ul>
                @foreach($subjects as $subject)
                    <li>
                        {{ $subject->name }} ({{ $subject->available_slots }} slots available)
                        <form action="{{ route('student.cart.add', $subject->id) }}" method="POST">
                            @csrf
                            <button type="submit">Add to Cart</button>
                        </form>
                    </li>
                @endforeach
            </ul>
        @endif
    </div>
@endsection
