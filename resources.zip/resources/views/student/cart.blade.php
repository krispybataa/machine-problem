@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Your Cart</h1>
        <!-- Display the subjects in the cart -->
        <form action="{{ route('student.cart.finalize') }}" method="POST">
            @csrf
            <button type="submit">Finalize Enrollment</button>
        </form>
    </div>
@endsection
